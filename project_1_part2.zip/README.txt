My Name: Kaih White
Helped by: Philip (TA)

I was challenged by the cost table building. At first I comepletely forgot that I was supposed to add the total cost up as I went towards the west. Once that was made clear by Philip, I was able to get my cost table to come out correctly by adding up the optimal costs as I went.
Next I had trouble with the blues lines being printed. I realised after getting a whole blue picture that I shouldn't use the row variable in my for loops as the variables used in the paint function. Once I created a seperate varaible in my loop just for iterating through rows and chose a switch rather than if statements, the code began to work beautifully.

I liked this assignment more than the last one. The only thing I didn't like at first was the issue of the vectors being backwards since they only have push back. One I started to use deques ( which have a push front method) my code became cleaner and easier for me to conceptually understand.

10 hours.

