My Name: Kaih White
Helped by: a TA (I forgot his name but he is in my lab section)

I was challenged by figuring out how to correctly input values into the 2d Vector because I forgot that the indicies start at 0 and end at -1 of the stated end.
I was also challenged by visualizing how the recursion was working, but I used the debugger to follow the recursive function through the example data and see where the recursive statement was making mistakes if finding the optimal cost. I saw that while my recursive arithmetic was right, I was first indexing the elevations vector wrong, and then realised that my comparisons for the optimal costs was wrong, so it was returning the wrong cost. Once I made these two edits, my recursion worked perfectly. EDIT: Re-upload because I realised that my code could not read the kilimanjaro file nor could it print pictures for anything but the example files. I stopped using string stream and instead just parse the whole file string by string so that the Kilomanjaro_hires file could be read. With the picture, the problem was that I was trying to make my scale as an integer and it was rounding to zero. Once I changed it to a double it worked perfectly.

I did like the part of the project where I was required to pull data out of files and then create a picture out of the data. I disliked the recursion part because to me recursion is hard to visualize and here it isn't even the most efficient alogrithm to solving the problem we are faced with here. I also didn't like how I was editing already written code in this project, it made it harder at first to understand what was going on because I had to read the already written code to then understand where I was supposed to write my own code. What I am saying is I enjoy writting my own projects from scratch more than I like editing someone elses code.

14 hours.

